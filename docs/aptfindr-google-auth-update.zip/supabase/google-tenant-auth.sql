-- Run as the database owner. Uses the existing app_users and tenant_profiles tables.
begin;
set local lock_timeout = '5s';
set local statement_timeout = '30s';
create schema if not exists aptfindr_private;
revoke all on schema aptfindr_private from public, anon;
grant usage on schema aptfindr_private to authenticated;

-- Fail safely if legacy case-variant duplicates need administrator review.
create unique index if not exists app_users_email_normalized_unique
  on public.app_users (lower(btrim(email)));

create or replace function aptfindr_private.complete_google_tenant_sign_in()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_auth auth.users%rowtype;
  v_identity jsonb;
  v_profile public.app_users%rowtype;
  v_email text;
  v_count integer;
  v_username text;
  v_username_attempt integer := 0;
begin
  if auth.uid() is null then
    raise exception 'A verified Google session is required.' using errcode = '42501';
  end if;
  select * into v_auth from auth.users where id = auth.uid();
  select identity_data into v_identity from auth.identities
    where user_id = auth.uid() and provider = 'google';
  if v_auth.email_confirmed_at is null or v_identity is null
     or coalesce(v_identity->>'email_verified', 'false') <> 'true'
     or lower(btrim(v_identity->>'email')) is distinct from lower(btrim(v_auth.email)) then
    raise exception 'A verified Google session is required.' using errcode = '42501';
  end if;
  v_email := lower(btrim(v_auth.email));
  if v_email is null or v_email = '' then
    raise exception 'A verified Google email is required.' using errcode = '42501';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('google-tenant:' || v_email, 0));
  -- Refuse ambiguous legacy ownership rather than merging or replacing data.
  select count(*) into v_count from public.app_users
    where auth_id = v_auth.id or lower(btrim(email)) = v_email;
  if v_count > 1 then
    raise exception 'Account identity conflict. Please contact support.';
  end if;
  select * into v_profile from public.app_users
    where auth_id = v_auth.id or lower(btrim(email)) = v_email for update;
  if found then
    if v_profile.role::text <> 'tenant' then
      raise exception 'This Google account is already associated with another account role. Please use your designated sign-in method.';
    end if;
    if v_profile.auth_id is not null and v_profile.auth_id <> v_auth.id then
      raise exception 'Account identity conflict. Please contact support.';
    end if;
    if v_profile.auth_id is null then
      update public.app_users set auth_id = v_auth.id where id = v_profile.id
        returning * into v_profile;
    end if;
  else
    -- Satisfy the existing NOT NULL/format/unique username constraints internally.
    loop
      v_username := 'usr_' || substr(md5(v_auth.id::text || ':' || v_username_attempt::text), 1, 26);
      exit when not exists (select 1 from public.app_users where lower(btrim(username)) = v_username);
      v_username_attempt := v_username_attempt + 1;
    end loop;
    insert into public.app_users
      (id, auth_id, email, name, username, role, status, is_verified,
       email_verified, verification_status, signup_source)
    values
      (v_auth.id, v_auth.id, v_email,
       coalesce(nullif(btrim(v_identity->>'full_name'), ''),
                nullif(btrim(v_identity->>'name'), ''), split_part(v_email, '@', 1)),
       v_username,
       'tenant', 'active', true, true, 'email_verified', 'google')
    returning * into v_profile;
  end if;
  if lower(v_profile.status) in ('disabled', 'inactive', 'deactivated', 'deleted') then
    raise exception 'This account has been deactivated. Contact an administrator.';
  end if;
  insert into public.tenant_profiles (user_id) values (v_profile.id)
    on conflict (user_id) do nothing;
  return to_jsonb(v_profile);
end;
$$;
revoke all on function aptfindr_private.complete_google_tenant_sign_in() from public, anon;
grant execute on function aptfindr_private.complete_google_tenant_sign_in() to authenticated;

create or replace function public.complete_google_tenant_sign_in()
returns jsonb language sql security invoker set search_path = '' as $$
  select aptfindr_private.complete_google_tenant_sign_in();
$$;
revoke all on function public.complete_google_tenant_sign_in() from public, anon;
grant execute on function public.complete_google_tenant_sign_in() to authenticated;

-- Complete trigger definition. Only the early Google return is new.
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
    meta            jsonb;
    v_role          public.app_user_role;
    v_username      text;
    v_name          text;
    v_mobile        text;
    v_avatar        text;
    v_status        text;
    v_is_verified   boolean;
    v_profile_id    uuid;
    v_existing_id   uuid;
    v_existing_role public.app_user_role;
begin
    -- Auth keeps the pending signup so it can deliver the confirmation link.
    -- Application profiles must wait for a verified email, including Google.
    if new.email_confirmed_at is null then
        return new;
    end if;

    -- Google profile creation is owned by the verified tenant-only RPC.
    -- Return before legacy linking can modify an existing non-tenant account.
    if coalesce(new.raw_app_meta_data ->> 'provider', '') = 'google'
       or coalesce(new.raw_app_meta_data -> 'providers', '[]'::jsonb) ? 'google' then
        return new;
    end if;

    -- Google OAuth normally supplies email/name/avatar, but not AptFindr's
    -- custom role or username fields.
    meta := coalesce(new.raw_user_meta_data, '{}'::jsonb);

    if new.email is null then
        raise exception 'Email is required to create an AptFindr profile.';
    end if;

    ---------------------------------------------------------------------------
    -- 1. Find an existing AptFindr profile.
    --    Prefer an exact auth_id match, then fall back to the same email.
    ---------------------------------------------------------------------------
    select u.id, u.role
      into v_existing_id, v_existing_role
      from public.app_users u
     where u.auth_id = new.id
     limit 1;

    if v_existing_id is null then
        select u.id, u.role
          into v_existing_id, v_existing_role
          from public.app_users u
         where lower(u.email) = lower(new.email)
         limit 1;
    end if;

    -- A new Google identity must complete the AptFindr role/account form.
    -- Existing accounts continue through the original linking path below.
    if v_existing_id is null
       and (
         coalesce(new.raw_app_meta_data ->> 'provider', '') = 'google'
         or coalesce(new.raw_app_meta_data -> 'providers', '[]'::jsonb) ? 'google'
       ) then
        return new;
    end if;

    ---------------------------------------------------------------------------
    -- 2. Resolve role.
    --    Existing admin/super_admin/landlord/tenant roles are preserved.
    --    New Google identities were deferred above. Password signup uses its
    --    selected role. Public signup metadata cannot create admins.
    ---------------------------------------------------------------------------
    if v_existing_id is not null then
        v_role := v_existing_role;
    elsif lower(coalesce(meta ->> 'role', '')) = 'landlord' then
        v_role := 'landlord'::public.app_user_role;
    else
        v_role := 'tenant'::public.app_user_role;
    end if;

    ---------------------------------------------------------------------------
    -- 3. Resolve a valid username.
    --    app_users_username_format_check allows only 4-30 characters.
    --    Never use the entire UUID because "user_" + 32 UUID characters is 37.
    ---------------------------------------------------------------------------
    v_username := lower(nullif(btrim(meta ->> 'username'), ''));

    if v_username is null
       or v_username !~ '^[a-z0-9_]{4,30}$'
       or exists (
            select 1
              from public.app_users u
             where lower(u.username) = lower(v_username)
               and u.id is distinct from v_existing_id
       )
    then
        -- 5 + 24 = 29 characters, safely inside the 30-character limit.
        v_username := 'user_' || substr(replace(new.id::text, '-', ''), 1, 24);
    end if;

    -- Extremely defensive collision fallback.
    if exists (
        select 1
          from public.app_users u
         where lower(u.username) = lower(v_username)
           and u.id is distinct from v_existing_id
    ) then
        -- 4 + 26 = 30 characters.
        v_username := 'usr_' || substr(md5(new.id::text), 1, 26);
    end if;

    ---------------------------------------------------------------------------
    -- 4. Resolve Google/profile metadata.
    --    app_users.name is NOT NULL, so always provide a fallback.
    ---------------------------------------------------------------------------
    v_name := coalesce(
        nullif(btrim(meta ->> 'name'), ''),
        nullif(btrim(meta ->> 'full_name'), ''),
        nullif(btrim(meta ->> 'display_name'), ''),
        nullif(split_part(new.email, '@', 1), ''),
        'AptFindr User'
    );

    v_mobile := nullif(btrim(coalesce(
        meta ->> 'mobile',
        meta ->> 'phone'
    )), '');

    v_avatar := nullif(btrim(coalesce(
        meta ->> 'avatar_url',
        meta ->> 'picture',
        meta ->> 'avatar'
    )), '');

    if v_role = 'landlord'::public.app_user_role then
        v_status := 'pending';
        v_is_verified := false;
    else
        v_status := 'active';
        v_is_verified := true;
    end if;

    ---------------------------------------------------------------------------
    -- 5. Link an existing app_users row or create a new one.
    ---------------------------------------------------------------------------
    if v_existing_id is not null then
        update public.app_users u
           set auth_id = new.id,
               username = case
                            when u.username is null
                                 or u.username !~ '^[A-Za-z0-9_]{4,30}$'
                            then v_username
                            else u.username
                          end,
               email = lower(new.email),
               name = case
                        when nullif(btrim(u.name), '') is null then v_name
                        else u.name
                      end,
               mobile = coalesce(u.mobile, v_mobile),
               avatar_url = coalesce(u.avatar_url, v_avatar),
               email_verified = new.email_confirmed_at is not null,
               verification_status = case
                   when new.email_confirmed_at is null then 'pending_email_verification'
                   else 'email_verified'
               end,
               signup_source = coalesce(u.signup_source, 'google'),
               updated_at = now()
         where u.id = v_existing_id
         returning u.id into v_profile_id;
    else
        insert into public.app_users (
            id,
            auth_id,
            username,
            email,
            name,
            role,
            status,
            mobile,
            avatar_url,
            is_verified,
            email_verified,
            verification_status,
            signup_source
        )
        values (
            new.id,
            new.id,
            v_username,
            lower(new.email),
            v_name,
            v_role,
            v_status,
            v_mobile,
            v_avatar,
            v_is_verified,
            new.email_confirmed_at is not null,
            case
                when new.email_confirmed_at is null then 'pending_email_verification'
                else 'email_verified'
            end,
            'google'
        )
        returning id into v_profile_id;
    end if;

    ---------------------------------------------------------------------------
    -- 6. Ensure the matching role profile exists.
    ---------------------------------------------------------------------------
    if v_role = 'tenant'::public.app_user_role then
        insert into public.tenant_profiles (user_id)
        values (v_profile_id)
        on conflict (user_id) do nothing;

    elsif v_role = 'landlord'::public.app_user_role then
        insert into public.landlord_profiles (
            user_id,
            permit_number,
            business_permit_number,
            is_verified
        )
        values (
            v_profile_id,
            nullif(meta ->> 'permitNumber', ''),
            nullif(meta ->> 'permitNumber', ''),
            false
        )
        on conflict (user_id) do update set
            permit_number = coalesce(
                landlord_profiles.permit_number,
                excluded.permit_number
            ),
            business_permit_number = coalesce(
                landlord_profiles.business_permit_number,
                excluded.business_permit_number
            );

    elsif v_role in (
        'admin'::public.app_user_role,
        'super_admin'::public.app_user_role
    ) then
        insert into public.admin_profiles (
            user_id,
            admin_level,
            department
        )
        values (
            v_profile_id,
            case
                when v_role = 'super_admin'::public.app_user_role
                    then 'Super Administrator'
                else 'Full Administrator'
            end,
            'Platform Administration'
        )
        on conflict (user_id) do nothing;
    end if;

    return new;
end;
$function$;

-- SECURITY INVOKER deliberately observes the caller of the INSERT/UPDATE.
-- The private provisioning function runs as owner; browser writes do not.
create or replace function aptfindr_private.guard_google_profile_writes()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  if current_user in ('authenticated', 'anon')
     and (auth.jwt()->'app_metadata'->>'provider' = 'google'
          or coalesce(auth.jwt()->'app_metadata'->'providers', '[]'::jsonb) ? 'google')
     and exists (
    select 1 from jsonb_array_elements(coalesce(auth.jwt()->'amr', '[]'::jsonb)) a
      where a->>'method' = 'oauth'
  ) then
    if tg_op = 'INSERT' then
      raise exception 'Google profiles must be created through tenant sign-in.' using errcode = '42501';
    elsif new.role is distinct from old.role or new.auth_id is distinct from old.auth_id then
      raise exception 'Google sign-in cannot change account roles or identity.' using errcode = '42501';
    end if;
  end if;
  return new;
end;
$$;
revoke all on function aptfindr_private.guard_google_profile_writes() from public, anon, authenticated;
drop trigger if exists guard_google_profile_writes on public.app_users;
create trigger guard_google_profile_writes before insert or update of role, auth_id
  on public.app_users for each row execute function aptfindr_private.guard_google_profile_writes();
notify pgrst, 'reload schema';
commit;
