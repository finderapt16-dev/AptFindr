-- Run as the database owner. Uses the existing app_users and tenant_profiles tables.
begin;
create schema if not exists aptfindr_private;
revoke all on schema aptfindr_private from public, anon;
grant usage on schema aptfindr_private to authenticated;

-- Fail safely if legacy case-variant duplicates need administrator review.
create unique index if not exists app_users_email_normalized_unique
  on public.app_users (lower(btrim(email)));

create or replace function aptfindr_private.complete_google_tenant_sign_in()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_auth auth.users%rowtype;
  v_identity jsonb;
  v_profile public.app_users%rowtype;
  v_email text;
  v_count integer;
begin
  if auth.uid() is null then
    raise exception 'A verified Google session is required.' using errcode = '42501';
  end if;
  select * into v_auth from auth.users where id = auth.uid();
  select identity_data into v_identity from auth.identities
    where user_id = auth.uid() and provider = 'google';
  if v_auth.email_confirmed_at is null or v_identity is null
     or coalesce(v_identity->>'email_verified', 'false') <> 'true'
     or lower(btrim(v_identity->>'email')) is distinct from lower(btrim(v_auth.email)) then
    raise exception 'A verified Google session is required.' using errcode = '42501';
  end if;
  v_email := lower(btrim(v_auth.email));
  perform pg_advisory_xact_lock(hashtextextended('google-tenant:' || v_email, 0));
  -- Refuse ambiguous legacy ownership rather than merging or replacing data.
  select count(*) into v_count from public.app_users
    where auth_id = v_auth.id or lower(btrim(email)) = v_email;
  if v_count > 1 then
    raise exception 'Account identity conflict. Please contact support.';
  end if;
  select * into v_profile from public.app_users
    where auth_id = v_auth.id or lower(btrim(email)) = v_email for update;
  if found then
    if v_profile.role::text <> 'tenant' then
      raise exception 'This Google account is already associated with another account role. Please use your designated sign-in method.';
    end if;
    if v_profile.auth_id is not null and v_profile.auth_id <> v_auth.id then
      raise exception 'Account identity conflict. Please contact support.';
    end if;
    if v_profile.auth_id is null then
      update public.app_users set auth_id = v_auth.id where id = v_profile.id
        returning * into v_profile;
    end if;
  else
    insert into public.app_users
      (id, auth_id, email, name, username, role, status, is_verified,
       email_verified, verification_status, signup_source)
    values
      (v_auth.id, v_auth.id, v_email,
       coalesce(nullif(btrim(v_identity->>'full_name'), ''),
                nullif(btrim(v_identity->>'name'), ''), split_part(v_email, '@', 1)),
       'usr_' || substr(md5(v_auth.id::text), 1, 26),
       'tenant', 'active', true, true, 'email_verified', 'google')
    returning * into v_profile;
  end if;
  if lower(v_profile.status) in ('disabled', 'inactive', 'deactivated', 'deleted') then
    raise exception 'This account has been deactivated. Contact an administrator.';
  end if;
  insert into public.tenant_profiles (user_id) values (v_profile.id)
    on conflict (user_id) do nothing;
  return to_jsonb(v_profile);
end;
$$;
revoke all on function aptfindr_private.complete_google_tenant_sign_in() from public, anon;
grant execute on function aptfindr_private.complete_google_tenant_sign_in() to authenticated;

create or replace function public.complete_google_tenant_sign_in()
returns jsonb language sql security invoker set search_path = '' as $$
  select aptfindr_private.complete_google_tenant_sign_in();
$$;
revoke all on function public.complete_google_tenant_sign_in() from public, anon;
grant execute on function public.complete_google_tenant_sign_in() to authenticated;

-- Google callbacks must use the verified, tenant-only provisioning function.
-- Keep the original password-signup trigger body and all non-Google behavior.
do $$
declare v_definition text;
begin
  select pg_get_functiondef('public.handle_new_auth_user()'::regprocedure) into v_definition;
  if position('if v_existing_id is null' || chr(13) || chr(10) || '       and (' in v_definition) > 0 then
    v_definition := replace(v_definition,
      'if v_existing_id is null' || chr(13) || chr(10) || '       and (', 'if (');
  elsif position('if v_existing_id is null' || chr(10) || '       and (' in v_definition) > 0 then
    v_definition := replace(v_definition,
      'if v_existing_id is null' || chr(10) || '       and (', 'if (');
  elsif position('if (' in v_definition) = 0 then
    raise exception 'Unexpected handle_new_auth_user definition. Review before applying.';
  end if;
  execute v_definition;
end;
$$;

-- SECURITY INVOKER deliberately observes the caller of the INSERT/UPDATE.
-- The private provisioning function runs as owner; browser writes do not.
create or replace function aptfindr_private.guard_google_profile_writes()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  if current_user in ('authenticated', 'anon') and exists (
    select 1 from jsonb_array_elements(coalesce(auth.jwt()->'amr', '[]'::jsonb)) a
      where a->>'method' = 'oauth'
  ) then
    if tg_op = 'INSERT' then
      raise exception 'Google profiles must be created through tenant sign-in.' using errcode = '42501';
    elsif new.role is distinct from old.role or new.auth_id is distinct from old.auth_id then
      raise exception 'Google sign-in cannot change account roles or identity.' using errcode = '42501';
    end if;
  end if;
  return new;
end;
$$;
revoke all on function aptfindr_private.guard_google_profile_writes() from public, anon, authenticated;
drop trigger if exists guard_google_profile_writes on public.app_users;
create trigger guard_google_profile_writes before insert or update of role, auth_id
  on public.app_users for each row execute function aptfindr_private.guard_google_profile_writes();
commit;
